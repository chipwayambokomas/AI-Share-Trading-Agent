# src/pipeline/model_trainer.py

import torch
import time
from tqdm import tqdm
from ..utils import print_header
from ..models.base_handler import BaseModelHandler

def run(train_loader, val_loader, model_handler: BaseModelHandler, settings, supports=None):
    """
    Stage 4: Initializes, trains, and validates the specified model using a
    unified training loop that leverages the model handler for specifics.
    """
    print_header("Stage 4: Model Development")
    print(f"Training {model_handler.name()} for {settings.PREDICTION_MODE} prediction...")
    
    # --- MODEL AND OPTIMIZER SETUP (Leveraging the Handler) ---
    # The handler abstracts away the complex if/elif logic for model building.
    sample_x, _ = next(iter(train_loader))
    num_nodes = sample_x.shape[2] if model_handler.is_graph_based() else None

    model = model_handler.build_model(supports=supports, num_nodes=num_nodes)
    optimizer = torch.optim.Adam(model.parameters(), lr=settings.LEARNING_RATE)
    
    # The handler provides the correct loss function (e.g., combined loss for TREND).
    loss_fn = model_handler.get_loss_function()
    
    best_val_loss = float('inf')
    best_model_state = None

    print("\nStarting model training...")
    start_time = time.time()
    for epoch in range(settings.EPOCHS):
        # --- TRAINING LOOP ---
        model.train()
        train_loss = 0.0
        
        # The tqdm progress bar is adopted from the unrefactored script for better UX.
        with tqdm(train_loader, unit="batch", desc=f"Epoch {epoch+1:2d}/{settings.EPOCHS}") as tepoch:
            for X_batch, y_batch in tepoch:
                optimizer.zero_grad()
                
                # Forward pass
                y_pred_raw = model(X_batch)
                
                # The handler adapts the model's raw output to match the target shape for loss calculation.
                # This replaces all the model-specific if/elif blocks for reshaping tensors.
                y_pred, y_batch_adapted = model_handler.adapt_output_for_loss(y_pred_raw, y_batch)
                
                # Some handlers might need a final adjustment (e.g., for y shape)
                y_pred, y_batch_adapted = model_handler.adapt_y_for_loss(y_pred, y_batch_adapted)

                # Calculate loss and backpropagate
                loss = loss_fn(y_pred, y_batch_adapted)
                loss.backward()
                
                # Gradient clipping is a best practice adopted from the unrefactored script.
                torch.nn.utils.clip_grad_norm_(model.parameters(), 5)
                
                optimizer.step()
                
                train_loss += loss.item()
                tepoch.set_postfix(loss=loss.item())

        # --- VALIDATION LOOP ---
        model.eval()
        val_loss = 0.0
        with torch.no_grad():
            for X_batch, y_batch in val_loader:
                y_pred_raw = model(X_batch)
                
                # The same handler logic is applied during validation.
                y_pred, y_batch_adapted = model_handler.adapt_output_for_loss(y_pred_raw, y_batch)
                y_pred, y_batch_adapted = model_handler.adapt_y_for_loss(y_pred, y_batch_adapted)

                val_loss += loss_fn(y_pred, y_batch_adapted).item()
        
        avg_train_loss = train_loss / len(train_loader)
        avg_val_loss = val_loss / len(val_loader)
        
        # Save the best model based on validation loss
        if avg_val_loss < best_val_loss:
            best_val_loss = avg_val_loss
            best_model_state = model.state_dict()
            
        print(f"Epoch {epoch+1:2d}/{settings.EPOCHS} Summary: Avg Train Loss: {avg_train_loss:.6f}, Avg Val Loss: {avg_val_loss:.6f}")
    
    training_time = time.time() - start_time
    print(f"\nModel training complete in {training_time:.2f} seconds.")
    
    # Load the best performing model state for evaluation
    model.load_state_dict(best_model_state)
    
    # The handler can also be used to extract learned components, like an adaptive adjacency matrix.
    final_adj_matrix = None
    if model_handler.is_graph_based():
        final_adj_matrix = model_handler.extract_adjacency_matrix(model)
        
    return model, training_time, final_adj_matrix