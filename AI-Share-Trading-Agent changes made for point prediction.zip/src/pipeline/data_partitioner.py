import numpy as np
import pandas as pd
import torch
from torch.utils.data import TensorDataset, DataLoader
from ..utils import print_header

def run(X, y, stock_ids, dates, is_graph_model: bool, settings):
    """
    Partitions data into training, validation, and test sets using a true
    chronological split based on sequence dates for all model types.
    """
    print_header("Stage 3: Data Partitioning")

    # --- UNIFIED CHRONOLOGICAL SPLIT LOGIC ---
    # This new logic applies to ALL models to ensure correctness.
    
    # 1. Get the start date of each sequence's prediction window.
    # The 'dates' array has shape (num_samples, horizon), so we take the first date.
    sequence_start_dates = dates[:, 0]
    
    # 2. Find the unique, sorted dates to determine the split points.
    unique_sorted_dates = np.unique(sequence_start_dates)
    
    # 3. Determine the actual date values for the splits.
    train_end_date = unique_sorted_dates[int(len(unique_sorted_dates) * settings.TRAIN_SPLIT)]
    val_end_date = unique_sorted_dates[int(len(unique_sorted_dates) * (settings.TRAIN_SPLIT + settings.VAL_SPLIT))]

    # 4. Find the indices in the original arrays that correspond to each time period.
    train_indices = np.where(sequence_start_dates <= train_end_date)[0]
    val_indices = np.where((sequence_start_dates > train_end_date) & (sequence_start_dates <= val_end_date))[0]
    test_indices = np.where(sequence_start_dates > val_end_date)[0]

    print(f"""
- Method: True Time-based split (Unified for all models).
- Train Split: Data up to {pd.to_datetime(train_end_date).strftime('%Y-%m-%d')}
- Validation Split: Data from {pd.to_datetime(train_end_date).strftime('%Y-%m-%d')} to {pd.to_datetime(val_end_date).strftime('%Y-%m-%d')}
- Test Split: Data after {pd.to_datetime(val_end_date).strftime('%Y-%m-%d')}
    """)

    # 5. Use these correct, date-based indices to slice all data arrays.
    X_train, y_train = X[train_indices], y[train_indices]
    X_val, y_val = X[val_indices], y[val_indices]
    X_test, y_test = X[test_indices], y[test_indices]
    
    # Handle test_stock_ids based on model type
    if is_graph_model:
        # Graph models need the full list of all possible nodes for the adjacency matrix
        test_stock_ids = stock_ids
    else:
        # DNN models only need the stock IDs present in the test set
        test_stock_ids = stock_ids[test_indices]
    # --- END OF NEW LOGIC ---

    print(f"\nData partitioning complete:")
    print(f"  - Training set size:   {len(X_train)}")
    print(f"  - Validation set size: {len(X_val)}")
    print(f"  - Test set size:       {len(X_test)}")

    X_train_t = torch.tensor(X_train, dtype=torch.float64)
    y_train_t = torch.tensor(y_train, dtype=torch.float64)
    X_val_t = torch.tensor(X_val, dtype=torch.float64)
    y_val_t = torch.tensor(y_val, dtype=torch.float64)
    X_test_t = torch.tensor(X_test, dtype=torch.float64)
    y_test_t = torch.tensor(y_test, dtype=torch.float64)

    if not is_graph_model and settings.PREDICTION_MODE == "POINT":
        if y_train_t.dim() == 3 and y_train_t.shape[2] == 1:
            y_train_t, y_val_t, y_test_t = [t.squeeze(-1) for t in (y_train_t, y_val_t, y_test_t)]

    train_dataset = TensorDataset(X_train_t, y_train_t)
    val_dataset = TensorDataset(X_val_t, y_val_t)

    # Shuffling is always False for time-series data to preserve order
    shuffle_train = False
    train_loader = DataLoader(train_dataset, batch_size=settings.BATCH_SIZE, shuffle=shuffle_train)
    val_loader = DataLoader(val_dataset, batch_size=settings.BATCH_SIZE, shuffle=False)

    print(f"\nPyTorch DataLoaders created with batch size: {settings.BATCH_SIZE}")
    print(f"  - Training data shuffling: {shuffle_train}")

    # The function signature now matches the pipeline's expectation
    return train_loader, val_loader, X_test_t, y_test_t, test_stock_ids