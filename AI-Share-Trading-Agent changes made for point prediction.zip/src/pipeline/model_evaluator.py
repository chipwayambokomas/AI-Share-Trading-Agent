# src/pipeline/model_evaluator.py (New)

import torch
import numpy as np
import pandas as pd
from sklearn.metrics import mean_squared_error, mean_absolute_error
from torch.utils.data import TensorDataset, DataLoader
import networkx as nx
from tqdm import tqdm # Import tqdm for progress bars
from ..utils import print_header
from ..models.base_handler import BaseModelHandler
import community as community_louvain

def _evaluate_point_prediction(model, X_test_t, y_test_t, test_stock_ids, scalers, handler, settings):
    """
    Evaluates point prediction performance using robust logic for flattening
    and inverse-transforming multi-step and multi-node forecasts.
    """
    print("\nEvaluating POINT prediction performance...")
    model.eval()

    test_dataset = TensorDataset(X_test_t)
    test_loader = DataLoader(test_dataset, batch_size=settings.BATCH_SIZE, shuffle=False)

    all_predictions = []
    with torch.no_grad():
        # The handler abstracts away the if/elif blocks for reshaping model output
        for X_batch_test in tqdm(test_loader, desc="Evaluating on test set"):
            pred_batch_raw = model(X_batch_test[0])
            pred_batch, _ = handler.adapt_output_for_loss(pred_batch_raw, None)
            all_predictions.append(pred_batch.cpu().numpy())

    predicted_scaled = np.concatenate(all_predictions, axis=0)
    actual_scaled = y_test_t.cpu().numpy()

    # --- START OF ADOPTED LOGIC ---
    # This improved logic correctly flattens multi-dimensional results for evaluation.
    
    # Flatten the potentially multi-dimensional actual and predicted arrays.
    # This handles shapes like (samples, horizon, nodes) or (samples, horizon)
    actual_flat = actual_scaled.flatten()
    predicted_flat = predicted_scaled.flatten()

    # Create corresponding StockID arrays that align with the flattened prices.
    if handler.is_graph_based():
        num_samples = actual_scaled.shape[0]
        horizon = actual_scaled.shape[1]
        num_nodes = actual_scaled.shape[2]
        
        # For graph models, test_stock_ids is the full ordered list of nodes.
        # Tile this list to match the flattened structure.
        final_stock_ids = np.tile(test_stock_ids, num_samples * horizon)
    else: # For DNN models (TCN, MLP)
        horizon = actual_scaled.shape[1] if actual_scaled.ndim > 1 else 1
        # For DNNs, test_stock_ids is already aligned with samples.
        # Repeat each stock ID for every step in its prediction horizon.
        final_stock_ids = np.repeat(test_stock_ids, horizon)

    # Inverse transform the prices one by one, using the correct scaler for each stock.
    actual_prices, predicted_prices = [], []
    target_col_idx = settings.FEATURE_COLUMNS.index(settings.TARGET_COLUMN)
    num_features = len(settings.FEATURE_COLUMNS)

    for i in tqdm(range(len(actual_flat)), desc="Inverse-transforming prices"):
        stock_id = final_stock_ids[i]
        scaler = scalers.get(stock_id)
        if scaler is None: continue

        dummy_actual = np.zeros(num_features)
        dummy_predicted = np.zeros(num_features)

        dummy_actual[target_col_idx] = actual_flat[i]
        dummy_predicted[target_col_idx] = predicted_flat[i]

        actual_prices.append(scaler.inverse_transform(dummy_actual.reshape(1, -1))[0, target_col_idx])
        predicted_prices.append(scaler.inverse_transform(dummy_predicted.reshape(1, -1))[0, target_col_idx])

    actual_prices = np.array(actual_prices)
    predicted_prices = np.array(predicted_prices)
    # --- END OF ADOPTED LOGIC ---

    mse = mean_squared_error(actual_prices, predicted_prices)
    mae = mean_absolute_error(actual_prices, predicted_prices)
    rmse = np.sqrt(mse)
    mape = np.mean(np.abs((actual_prices - predicted_prices) / (actual_prices + 1e-8))) * 100

    print("\nQuantitative Metrics (All Stocks):")
    print(f"  - RMSE: {rmse:.2f}, MAE: {mae:.2f}, MAPE: {mape:.2f}%")

    results_df = pd.DataFrame({
        'StockID': final_stock_ids,
        'Actual_Price': actual_prices, 
        'Predicted_Price': predicted_prices
    })
    save_path = f"{settings.RESULTS_DIR}/{settings.MODEL_TYPE}/evaluation_POINT_{settings.MODEL_TYPE}.csv"
    results_df.to_csv(save_path, index=False)
    print(f"\nPoint prediction evaluation results saved to '{save_path}'.")


def _evaluate_trend_prediction(model, X_test_t, y_test_t, test_stock_ids, scalers, handler, settings):
    # This function's logic was already robust and remains largely unchanged.
    # The handler correctly abstracts away model-specific output shapes.
    print("\nEvaluating TREND prediction performance...")
    model.eval()

    test_dataset = TensorDataset(X_test_t, y_test_t)
    test_loader = DataLoader(test_dataset, batch_size=settings.BATCH_SIZE, shuffle=False)

    all_predictions, all_actuals = [], []
    with torch.no_grad():
        for X_batch, y_batch in test_loader:
            pred_batch_raw = model(X_batch)
            # The handler call replaces all the if/elif blocks for reshaping
            pred_batch, _ = handler.adapt_output_for_loss(pred_batch_raw, y_batch)
            all_predictions.append(pred_batch.cpu().numpy())
            all_actuals.append(y_batch.cpu().numpy())
    
    predicted_scaled = np.concatenate(all_predictions, axis=0)
    actual_scaled = np.concatenate(all_actuals, axis=0)

    if handler.is_graph_based():
        actual_slopes = scalers['slope'].inverse_transform(actual_scaled[..., 0]).flatten()
        actual_durations = scalers['duration'].inverse_transform(actual_scaled[..., 1]).flatten()
        predicted_slopes = scalers['slope'].inverse_transform(predicted_scaled[..., 0]).flatten()
        predicted_durations = scalers['duration'].inverse_transform(predicted_scaled[..., 1]).flatten()
        stock_ids_flat = np.tile(test_stock_ids, actual_scaled.shape[0])
    else: # For TCN/MLP
        actual_slopes = scalers['slope'].inverse_transform(actual_scaled[:, 0].reshape(-1, 1)).flatten()
        actual_durations = scalers['duration'].inverse_transform(actual_scaled[:, 1].reshape(-1, 1)).flatten()
        predicted_slopes = scalers['slope'].inverse_transform(predicted_scaled[:, 0].reshape(-1, 1)).flatten()
        predicted_durations = scalers['duration'].inverse_transform(predicted_scaled[:, 1].reshape(-1, 1)).flatten()
        stock_ids_flat = test_stock_ids
        
    actual_angles = np.degrees(np.arctan(actual_slopes))
    predicted_angles = np.degrees(np.arctan(predicted_slopes))
    rmse_angle = np.sqrt(mean_squared_error(actual_angles, predicted_angles))
    mae_angle = mean_absolute_error(actual_angles, predicted_angles)
    print(f"\n  --- Slope Angle Prediction (degrees) ---")
    print(f"  - RMSE: {rmse_angle:.4f}, MAE: {mae_angle:.4f}")

    rmse_duration = np.sqrt(mean_squared_error(actual_durations, predicted_durations))
    mae_duration = mean_absolute_error(actual_durations, predicted_durations)
    print(f"\n  --- Duration Prediction (days) ---")
    print(f"  - RMSE: {rmse_duration:.2f}, MAE: {mae_duration:.2f}")

    results_df = pd.DataFrame({
        'StockID': stock_ids_flat,
        'Actual_Slope_Angle': actual_angles,
        'Predicted_Slope_Angle': predicted_angles,
        'Actual_Duration': actual_durations,
        'Predicted_Duration': predicted_durations
    })
    save_path = f"{settings.RESULTS_DIR}/{settings.MODEL_TYPE}/evaluation_TREND_{settings.MODEL_TYPE}.csv"
    results_df.to_csv(save_path, index=False)
    print(f"\nTrend evaluation results saved to '{save_path}'.")


def _calculate_graph_metrics(adj_matrix, stock_ids, settings, percentile_threshold):
    # This function from the original pipeline is superior due to the configurable
    # percentile threshold for pruning and is therefore kept.
    print_header("Network Analysis Metrics")
    if hasattr(adj_matrix, 'cpu'):
        adj_numpy = adj_matrix.cpu().numpy()
    else:
        adj_numpy = adj_matrix
    
    threshold = np.percentile(adj_numpy, percentile_threshold)
    print(f"Pruning graph: Keeping top {100 - percentile_threshold}% of edges (Threshold value: {threshold:.6f}).")

    pruned_adj_numpy = np.copy(adj_numpy)
    pruned_adj_numpy[pruned_adj_numpy < threshold] = 0

    G = nx.from_numpy_array(pruned_adj_numpy, create_using=nx.DiGraph)
    
    if G.number_of_edges() == 0:
        print("WARNING: Threshold is too high, no edges remain. Try a lower percentile.")
        return

    mapping = {i: name for i, name in enumerate(stock_ids)}
    nx.relabel_nodes(G, mapping, copy=False)
    
    in_degree_centrality = nx.in_degree_centrality(G)
    out_degree_centrality = nx.out_degree_centrality(G)
    betweenness_centrality = nx.betweenness_centrality(G)
    try:
        eigenvector_centrality = nx.eigenvector_centrality(G, max_iter=5000)
    except (nx.PowerIterationFailedConvergence, nx.NetworkXError):
        eigenvector_centrality = nx.pagerank(G)
    local_clustering_coeff = nx.clustering(G)
    partition = community_louvain.best_partition(G.to_undirected())

    analysis_df = pd.DataFrame(index=G.nodes())
    analysis_df['in_degree_centrality'] = analysis_df.index.map(in_degree_centrality)
    analysis_df['out_degree_centrality'] = analysis_df.index.map(out_degree_centrality)
    analysis_df['betweenness_centrality'] = analysis_df.index.map(betweenness_centrality)
    analysis_df['eigenvector_centrality_or_pagerank'] = analysis_df.index.map(eigenvector_centrality)
    analysis_df['local_clustering_coeff'] = analysis_df.index.map(local_clustering_coeff)
    analysis_df['community_id'] = analysis_df.index.map(partition)

    print("\n--- Network Metrics per Stock (on Pruned Graph) ---")
    print(analysis_df)

    save_path = f"{settings.RESULTS_DIR}/{settings.MODEL_TYPE}/evaluation_GRAPH_{settings.PREDICTION_MODE}__{settings.MODEL_TYPE}.csv"
    analysis_df.to_csv(save_path, index=True)
    print(f"\nGRAPH evaluation results saved to '{save_path}'.")


def run(model, X_test_t, y_test_t, test_stock_ids, scalers, handler: BaseModelHandler, settings, adj_matrix=None):
    """
    Stage 5: Assesses final model performance and calculates network metrics if applicable.
    """
    print_header("Stage 5: Model Evaluation")
    
    if settings.PREDICTION_MODE == "POINT":
        _evaluate_point_prediction(model, X_test_t, y_test_t, test_stock_ids, scalers, handler, settings)
    elif settings.PREDICTION_MODE == "TREND":
        _evaluate_trend_prediction(model, X_test_t, y_test_t, test_stock_ids, scalers, handler, settings)
          
    if handler.is_graph_based() and adj_matrix is not None:
        _calculate_graph_metrics(adj_matrix, test_stock_ids, settings, settings.EVAL_THRESHOLD)